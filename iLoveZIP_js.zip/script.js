// ====================== PENGATURAN ======================
const CORRECT_PASSCODE = "2509"; // Ganti sesuai keinginanmu
// Hint bisa diganti di index.html

// ====================== DATA WHATSAPP ======================
const whatsappChats = {
 "mnyt🐵": [
 { from: "mnyt🐵", text: "woy", time: "16:32" },
 { from: "mnyt🐵", text: "woy", time: "16:32" },
 { from: "mnyt🐵", text: "jamet", time: "16:32" },
 { from: "mnyt🐵", text: "WOY", time: "16:32" },
 { from: "Aku", text: "aoa si mnyt", time: "16:40" },
 { from: "Aku", text: "brisik", time: "16:40" },
 { from: "mnyt🐵", text: "dah sampe rumah?", time: "16:42" },
 { from: "Aku", text: "sypa", time: "16:43" },
 { from: "mnyt🐵", text: "anjing gue", time: "16:43" },
 { from: "Aku", text: "🖕", time: "16:43" },
 { from: "mnyt🐵", text: "ya lo lah bego", time: "16:44" },
 { from: "Aku", text: "udah", time: "16:44" },
 { from: "mnyt🐵", text: "woy", time: "16:46" },
 { from: "mnyt🐵", text: "woy", time: "16:46" },
 { from: "mnyt🐵", text: "WOYYYYYYYYY", time: "16:46" },
 { from: "Aku", text: "gausah woy woy", time: "16:47" },
 { from: "Aku", text: "gw punya nama anjig", time: "16:47" },
 { from: "mnyt🐵", text: "hehe", time: "16:47" },
 { from: "Aku", text: "lo bener2 ya", time: "16:48" },
 { from: "Aku", text: "pengen gw ptahib tuh tangan rasanya", time: "16:48" },
 { from: "Aku", text: "ini lgi, kaoan aj lo buka hp gw. Lo hack ya", time: "16:48" },
 { from: "Aku", text: "perasaan konta lo gue block", time: "16:48" },
 { from: "mnyt🐵", text: "lagian lo lebay bgt pake segala block gue segala", time: "16:49" },
 { from: "mnyt🐵", text: "atau lo masih belom bisa moveon ya dari gue? makanya lo blok gue🤭", time: "16:49" },
 { from: "Aku", text: "[Stiker: Ngomong sama pantat]", time: "16:50" },
 { from: "mnyt🐵", text: "sorry, tdi gw panik banget sumpah", time: "16:51" },
 { from: "mnyt🐵", text: "gue ga liat-liat siapa yang gue tarik, eh taunya mak Lampir awokawok", time: "16:51" },
 { from: "Aku", text: "[Stiker: Foto tidur]", time: "16:52" },
 { from: "Aku", text: "seraj lo dab anjing", time: "16:52" },
 { from: "mnyt🐵", text: "ini typo lo kok makin menjadi-jadi ya", time: "16:53" },
 { from: "Aku", text: "sksk gw", time: "16:53" },
 { from: "Aku", text: "asla lo tau, padahak gw lagi mode ninja ya, eh main lu tarik2 aja", time: "16:54" },
 { from: "Aku", text: "klo semosal ada yang nyidul gw gimaan bnagsat", time: "16:54" },
 { from: "Aku", text: "bbisa hanbsur reputasi gw", time: "16:54" },
 { from: "mnyt🐵", text: "alah", time: "16:55" },
 { from: "mnyt🐵", text: "emang masih ada yang mau nge-fans sama artis rewel kayak lo?", time: "16:55" },
 { from: "mnyt🐵", text: "harusnya lo bangga dikit lah, secara gak langsung gue akuin jadi pacar lagi", time: "16:55" },
 { from: "mnyt🐵", text: "vokalis band nomor satu nih yang ngomong", time: "16:56" },
 { from: "Aku", text: "NAJIS", time: "16:56" },
 { from: "Aku", text: "NAJIS", time: "16:56" },
 { from: "mnyt🐵", text: "heh, kaca di rumah lo pecah ya?", time: "16:57" },
 { from: "mnyt🐵", text: "sok najis najis", time: "16:57" },
 { from: "mnyt🐵", text: "dulu lo yang nembak gue pake surat warna pink bau parfum malaikat subuh itu ya!", time: "16:57" },
 { from: "mnyt🐵", text: "jangan amnesia lo", time: "16:57" },
 { from: "mnyt🐵", text: "gue sebenernya juga heran, kenapa dulu mau-mauan sama cwe yang kalo ketawa suaranya kayak knalpot racing", time: "16:58" },
 { from: "Aku", text: "ITU SURAT DITITIPIN TEMEN GUE YA, GUE CUMA BANTU NGASIHIN", time: "16:58" },
 { from: "Aku", text: "pokonya beok lo harus klarifikadi ke nykap lo klo qta gk ada apa2", time: "16:59" },
 { from: "Aku", text: "ga dudi gw masuk ke selasih keliuarga lo", time: "16:59" },
 { from: "mnyt🐵", text: "gak bisa", time: "17:00" },
 { from: "mnyt🐵", text: "nyokap gue udah terlanjur suka sama lo", time: "17:00" },
 { from: "mnyt🐵", text: "katanya \"wah pacar kamu kalem ya, pendiem walaupun pake masker\"", time: "17:00" },
 { from: "mnyt🐵", text: "awokawok", time: "17:01" },
 { from: "mnyt🐵", text: "nyokap gatau aja, kalo lo ga pake masker mungkin meja cafe abis lo lalapin", time: "17:01" },
 { from: "Aku", text: "JIAZA ANJING", time: "17:02" },
 { from: "Aku", text: "gw blok ya iji", time: "17:02" },
 { from: "mnyt🐵", text: "jangan diblok dong, ntar kalo gue disuruh bawa lo makan bareng keluarga gimana?", time: "17:03" },
 { from: "Aku", text: "[Kontak diblokir]", time: "17:03" }
 ],

 "Stezi": [
 { from: "Stezi", text: "Cayra", time: "09:12" },
 { from: "Stezi", text: "Cayraa", time: "09:13" },
 { from: "Stezi", text: "Jawab", time: "09:14" },
 { from: "Aku", text: "ap sih", time: "09:20" },
 { from: "Stezi", text: "Lo dimana?", time: "09:21" },
 { from: "Aku", text: "di puncak monas", time: "09:22" },
 { from: "Stezi", text: "serius monyet", time: "09:22" },
 { from: "Stezi", text: "Syuting jam 10 jangan lupa", time: "09:23" },
 { from: "Aku", text: "iya iya tau", time: "09:25" },
 { from: "Stezi", text: "Jangan iya iya doang", time: "09:25" },
 { from: "Stezi", text: "besok harus bangun pagi, ntar ada driver jemput", time: "09:26" },
 { from: "Aku", text: "gausah gw mau nytir sndiri", time: "09:28" },
 { from: "Stezi", text: "Cayra sumpah ya", time: "09:28" },
 { from: "Stezi", text: "Jangan ulangi kejadian kemarin", time: "09:29" },
 { from: "Aku", text: "iyahhh", time: "09:30" },
 { from: "Stezi", text: "Cepat. Jangan bikin gue telpon lagi.", time: "09:31" }
 ],

 "Yebi": [
 { from: "Yebi", text: "Cay, besok jadi nonton bareng?", time: "22:15" },
 { from: "Aku", text: "Liat beosk dehg", time: "22:20" },
 { from: "Yebi", text: "Jangan liat liat besok  mulu", time: "22:21" }
 ],

 "Sutradara": [
 { from: "Sutradara", text: "Cayra, besok scene emosionalnya kita ambil pagi ya", time: "20:45" },
 { from: "Aku", text: "Siap kak", time: "20:50" }
 ]
};

// ====================== DATA INSTAGRAM DM ======================
const instagramDMs = {
 "PremRajveeeKumar_Real": [
 { from: "PremRajveeeKumar_Real", text: "Halah, sok cantik lo", time: "14:05" },
 { from: "PremRajveeeKumar_Real", text: "Padahal aslinya kayak remah rengginang kalo ga pake filter", time: "14:05" },
 { from: "PremRajveeeKumar_Real", text: "Artis sombong", time: "14:06" },
 { from: "PremRajveeeKumar_Real", text: "Sok jual mahal banget", time: "14:06" },
 { from: "PremRajveeeKumar_Real", text: "Rasain tuh, ban mobilnya kempes kan tadi? awokawok", time: "14:07" },
 { from: "PremRajveeeKumar_Real", text: "Mending liat hidung gue, asli dari lahir", time: "14:07" },
 { from: "PremRajveeeKumar_Real", text: "Ga kaya hidung lo hasil vermak", time: "14:08" },
 { from: "PremRajveeeKumar_Real", text: "Lebih cakepan juga gue kemana-mana", time: "14:08" },
 { from: "PremRajveeeKumar_Real", text: "Liat nih foto gue pas lagi senyum, manis kan?", time: "14:09" },
 { from: "PremRajveeeKumar_Real", text: "Pantesan tadi di jalan banyak pohon", time: "14:09" },
 { from: "PremRajveeeKumar_Real", text: "Ternyata ada titisan reog mobilnya mogok awokawok", time: "14:10" },
 { from: "PremRajveeeKumar_Real", text: "Lo kalo matah mukanya kaya aspal baru ya", time: "14:10" },
 { from: "PremRajveeeKumar_Real", text: "Kasar-kasar gimana gitu", time: "14:11" },
 { from: "Aku", text: "HEH", time: "14:15" },
 { from: "Aku", text: "lw syp?", time: "14:15" },
 { from: "Aku", text: "brnainya lw ngatain gue reof", time: "14:16" },
 { from: "Aku", text: "Lw gak tau gw siapa?", time: "14:16" },
 { from: "PremRajveeeKumar_Real", text: "waduh, mbak artis marah", time: "14:17" },
 { from: "PremRajveeeKumar_Real", text: "Takuttt...", time: "14:17" },
 { from: "PremRajveeeKumar_Real", text: "Eh ga deng, lebih takut liat filter lo yang tebelnya kayak bedak nyonya-nyonya", time: "14:18" },
 { from: "PremRajveeeKumar_Real", text: "Lagian siapa yang ga kenal lo, si artis yang hobinya akting nangis padahal aslinya galak kayak herder", time: "14:18" },
 { from: "Aku", text: "BANGKE ORANG MANA SIH LU MNYT", time: "14:20" },
 { from: "Aku", text: "[Mencoba menelepon... tidak diangkat]", time: "14:21" }
 ]
};

// ====================== DATA NOTES ======================
const notesData = [
 {
 title: "Hari ini berantakan",
 date: "23 Oktober 2026",
 body: "Jiaza masih aja bikin ulah. Udah diblok tapi masih kepikiran. Besok syuting, harus fokus."
 },
 {
 title: "Stezi marah lagi",
 date: "22 Oktober 2026",
 body: "Stezi bilang jangan ulangi kejadian kemarin. Aku janji sih... tapi ya susah."
 }
];


// ====================== APLIKASI & NAVIGASI ======================
let currentApp = "";
let currentChatName = "";
let currentChatData = null;

const contacts = {
  "mnyt🐵": { image: "assets/jiwoo.jpg", initial: "J", subtitle: "terakhir dilihat hari ini" },
  "Stezi": { image: "assets/stella.jpg", initial: "S", subtitle: "online" },
  "Yebi": { image: "assets/yuha.jpg", initial: "Y", subtitle: "online" },
  "Sutradara": { image: "", initial: "🎬", subtitle: "akun bisnis" },
  "PremRajveeeKumar_Real": { image: "assets/prem.jpg", initial: "P", subtitle: "Instagram" },
  "Cayra": { image: "assets/carmen.jpg", initial: "C", subtitle: "online" }
};

const apps = [
  { id:"photos", label:"Photos", icon:"✿", className:"photos" },
  { id:"whatsapp", label:"WhatsApp", icon:"◔", className:"whatsapp" },
  { id:"instagram", label:"Instagram", icon:"◎", className:"instagram" },
  { id:"twitter", label:"X", icon:"𝕏", className:"twitter" },
  { id:"notes", label:"Notes", icon:"▤", className:"notes" },
  { id:"camera", label:"Camera", icon:"◉", className:"camera" },
  { id:"roblox", label:"Roblox", icon:"◇", className:"roblox" },
  { id:"settings", label:"Settings", icon:"⚙", className:"settings" },
  { id:"mail", label:"Mail", icon:"✉", className:"mail" },
  { id:"music", label:"Music", icon:"♫", className:"music" }
];

function updateTime() {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
  const time = document.getElementById('time');
  const date = document.getElementById('date');
  if (time) time.textContent = timeStr;
  if (date) date.textContent = dateStr;
  ['home-time','wa-time','ig-time','lock-status-time'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = timeStr;
  });
  document.querySelectorAll('.live-time').forEach(el => el.textContent = timeStr);
}
setInterval(updateTime, 1000);
updateTime();

function buildHomeApps() {
  const grid = document.getElementById('apps-grid');
  if (!grid) return;
  grid.innerHTML = apps.map(app => `
    <button class="app-tile" type="button" onclick="openApp('${app.id}')">
      <span class="app-icon ${app.className}">${app.icon}</span>
      <span class="app-label">${app.label}</span>
    </button>`).join('');
}
buildHomeApps();

function showPasscode() {
  document.getElementById('passcode-screen').classList.remove('hidden');
  document.getElementById('passcode').focus();
}
document.getElementById('unlock-button').addEventListener('click', showPasscode);
document.getElementById('lockscreen').addEventListener('click', function(event) {
  if (!event.target.closest('button,input')) showPasscode();
});
document.getElementById('passcode').addEventListener('keydown', event => {
  if (event.key === 'Enter') checkPasscode();
});

function cancelPasscode() {
  document.getElementById('passcode-screen').classList.add('hidden');
  document.getElementById('passcode').value = '';
  document.getElementById('passcode-error').textContent = '';
}
function checkPasscode() {
  const input = document.getElementById('passcode').value;
  if (input === CORRECT_PASSCODE) {
    document.getElementById('lockscreen').classList.add('hidden');
    document.getElementById('homescreen').classList.remove('hidden');
    document.getElementById('passcode-screen').classList.add('hidden');
    document.getElementById('passcode-error').textContent = '';
    document.getElementById('passcode').value = '';
  } else {
    document.getElementById('passcode-error').textContent = 'Kode sandi salah, coba lagi.';
    document.getElementById('passcode').value = '';
  }
}

function hideAllApps() {
  document.querySelectorAll('.app-screen').forEach(el => el.classList.add('hidden'));
}
function openApp(name) {
  const target = document.getElementById(name);
  if (!target) return;
  hideAllApps();
  document.getElementById('homescreen').classList.add('hidden');
  target.classList.remove('hidden');
  currentApp = name;
  if (name === 'whatsapp') renderChatList('whatsapp');
  if (name === 'instagram') renderChatList('instagram');
  if (name === 'notes') renderNotes();
  if (name === 'photos') renderPhotos();
}
function closeApp() {
  hideAllApps();
  document.getElementById('homescreen').classList.remove('hidden');
  currentApp = '';
}
function backToList() {
  document.getElementById('chat-detail').classList.add('hidden');
  const listScreen = document.getElementById(currentApp);
  if (listScreen) listScreen.classList.remove('hidden');
  currentChatName = '';
  currentChatData = null;
}

function safeText(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function avatarMarkup(name, small=false) {
  const person = contacts[name] || { image:"", initial:(name || "?").charAt(0).toUpperCase() };
  const image = person.image ? `<img src="${person.image}" alt="" onerror="this.style.display='none'">` : '';
  return `<div class="avatar ${small ? 'chat-avatar' : ''}">${image}<span>${safeText(person.initial)}</span></div>`;
}
function renderChatList(app) {
  const data = app === 'whatsapp' ? whatsappChats : instagramDMs;
  const container = document.getElementById(app + '-list');
  if (!container) return;
  const names = Object.keys(data);
  container.innerHTML = names.map(name => {
    const msgs = data[name];
    const lastMsg = msgs[msgs.length - 1];
    const person = contacts[name] || { subtitle: "" };
    const time = lastMsg ? lastMsg.time : "";
    const preview = lastMsg ? lastMsg.text : "";
    return `<button type="button" class="wa-contact" onclick="openChat('${app}', ${JSON.stringify(name).replace(/"/g,'&quot;')})">
      ${avatarMarkup(name)}
      <span class="wa-contact-info">
        <span class="wa-contact-top"><span class="wa-name">${safeText(name)}</span><span class="wa-time">${safeText(time)}</span></span>
        <span class="wa-preview">${safeText(preview)}</span>
      </span>
    </button>`;
  }).join('');
}
function openChat(app, name) {
  const data = app === 'whatsapp' ? whatsappChats : instagramDMs;
  const messages = data[name];
  if (!messages) return;
  currentApp = app;
  currentChatName = name;
  currentChatData = messages;
  document.getElementById(app).classList.add('hidden');
  const chatScreen = document.getElementById('chat-detail');
  chatScreen.classList.remove('hidden');
  chatScreen.classList.toggle('instagram-chat', app === 'instagram');
  document.getElementById('chat-name').textContent = name;
  const person = contacts[name] || { image:"", initial:(name || "?").charAt(0).toUpperCase(), subtitle:"" };
  const img = document.getElementById('chat-pp');
  img.src = person.image || '';
  img.style.display = person.image ? '' : 'none';
  document.getElementById('chat-initial').textContent = person.initial;
  document.getElementById('chat-subtitle').textContent = person.subtitle || (app === 'instagram' ? 'Instagram' : 'terakhir dilihat');
  document.getElementById('chat-context').textContent = app === 'instagram' ? 'Pesan langsung' : 'Hari ini';
  document.getElementById('message-input').placeholder = app === 'instagram' ? 'Kirim pesan...' : 'Pesan';
  renderMessages(messages, app);
}
function renderMessages(messages, app) {
  const container = document.getElementById('chat-messages');
  container.innerHTML = messages.map(msg => {
    const mine = msg.from === "Aku";
    const text = String(msg.text);
    const isSticker = /^\[Stiker:/.test(text);
    const isCall = /^\[Mencoba menelepon/.test(text);
    let body = safeText(text);
    if (isSticker) {
      const stickerName = text.replace(/^\[Stiker:\s*/,'').replace(/\]$/,'');
      const stickerArt = /pantat/i.test(stickerName) ? '🍑' : '😴';
      body = `<span class="sticker-art">${stickerArt}</span><span>${safeText(stickerName)}</span>`;
    }
    return `<div class="message ${mine ? 'me' : 'them'} ${isSticker ? 'sticker-message' : ''} ${isCall ? 'call-message' : ''}">${body}<div class="time">${safeText(msg.time || '')}</div></div>`;
  }).join('');
  const scroll = document.getElementById('chat-scroll');
  requestAnimationFrame(() => { scroll.scrollTop = scroll.scrollHeight; });
}
document.getElementById('message-form').addEventListener('submit', event => {
  event.preventDefault();
  const input = document.getElementById('message-input');
  const text = input.value.trim();
  if (!text || !currentChatData) return;
  const now = new Date().toLocaleTimeString('id-ID', {hour:'2-digit',minute:'2-digit'});
  currentChatData.push({from:'Aku', text, time:now});
  input.value = '';
  renderMessages(currentChatData, currentApp);
  renderChatList(currentApp);
});

function renderNotes() {
  const container = document.getElementById('notes-content');
  if (!container) return;
  container.innerHTML = notesData.map(n => `
    <article class="note-item"><h3>${safeText(n.title)}</h3><small>${safeText(n.date)}</small><p>${safeText(n.body)}</p></article>
  `).join('');
}
function renderPhotos() {
  const container = document.getElementById('photos-content');
  if (!container) return;
  container.innerHTML = `<div class="empty-state"><div>▧</div><strong>Memories</strong><p>Tambahkan foto pilihanmu ke folder assets untuk mulai mengisi galeri Cayra.</p></div>`;
}

// Dock and home-indicator behavior
document.querySelector('.home-indicator').addEventListener('click', closeApp);
